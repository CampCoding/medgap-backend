const express = require("express");
const router = express.Router();
const ctrl = require("../../controllers/student/digitalLibrary");

// Student modules (enrolled subjects)
router.get("/modules", ctrl.listStudentModules);

// Books by module + optional selected book via ?ebook_id=
router.get("/modules/:module_id/books", ctrl.listModuleBooks);
router.get("/modules/bulk/:module_id/books", ctrl.listBooksByModuleByBulk);

// Increment view count
router.post("/books/:ebook_id/view", ctrl.viewBook);

// Save annotation for a book
router.post("/books/:ebook_id/annotations", ctrl.saveAnnotation);

module.exports = router;
